package se.krill.fotobacken.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("fotobacken", Context.MODE_PRIVATE)

    private fun readSet(key: String): Set<String> = sp.getStringSet(key, null)?.toSet() ?: emptySet()

    private val _hiddenPhotos = MutableStateFlow(readSet("hiddenPhotos"))
    val hiddenPhotos: StateFlow<Set<String>> = _hiddenPhotos

    private val _hiddenFolders = MutableStateFlow(readSet("hiddenFolders"))
    val hiddenFolders: StateFlow<Set<String>> = _hiddenFolders

    private val _favorites = MutableStateFlow(readSet("favorites"))
    val favorites: StateFlow<Set<String>> = _favorites

    private val _autoShowNew = MutableStateFlow(sp.getBoolean("autoShowNew", true))
    val autoShowNew: StateFlow<Boolean> = _autoShowNew

    private val _lockHidden = MutableStateFlow(sp.getBoolean("lockHidden", true))
    val lockHidden: StateFlow<Boolean> = _lockHidden

    private val _columns = MutableStateFlow(sp.getInt("columns", 3))
    val columns: StateFlow<Int> = _columns

    // Det gamla temat "ljus" blir Bärnsten i ljust läge.
    private val savedTheme = sp.getString("theme", "barnsten") ?: "barnsten"
    private val _theme = MutableStateFlow(if (savedTheme == "ljus") "barnsten" else savedTheme)
    val theme: StateFlow<String> = _theme

    /** system, ljust eller morkt */
    private val _mode = MutableStateFlow(sp.getString("mode", null) ?: if (savedTheme == "ljus") "ljust" else "morkt")
    val mode: StateFlow<String> = _mode

    /** bilder, mappar eller dropbox */
    private val _startTab = MutableStateFlow(sp.getString("startTab", "bilder") ?: "bilder")
    val startTab: StateFlow<String> = _startTab

    private val _folderOrder = MutableStateFlow(
        (sp.getString("folderOrder", "") ?: "").split('\n').filter { it.isNotBlank() }
    )
    val folderOrder: StateFlow<List<String>> = _folderOrder

    fun setMode(v: String) { _mode.value = v; sp.edit().putString("mode", v).apply() }
    fun setStartTab(v: String) { _startTab.value = v; sp.edit().putString("startTab", v).apply() }
    fun setFolderOrder(v: List<String>) {
        _folderOrder.value = v
        sp.edit().putString("folderOrder", v.joinToString("\n")).apply()
    }

    private val _groupPhotos = MutableStateFlow(sp.getBoolean("groupPhotos", true))
    val groupPhotos: StateFlow<Boolean> = _groupPhotos

    private val _groupFolders = MutableStateFlow(sp.getBoolean("groupFolders", true))
    val groupFolders: StateFlow<Boolean> = _groupFolders

    /** av, mjuk, kub eller stapel */
    private val _swipeEffect = MutableStateFlow(sp.getString("swipeEffect", "kub") ?: "kub")
    val swipeEffect: StateFlow<String> = _swipeEffect

    fun setTheme(v: String) { _theme.value = v; sp.edit().putString("theme", v).apply() }
    fun setGroupPhotos(v: Boolean) { _groupPhotos.value = v; sp.edit().putBoolean("groupPhotos", v).apply() }
    fun setGroupFolders(v: Boolean) { _groupFolders.value = v; sp.edit().putBoolean("groupFolders", v).apply() }
    fun setSwipeEffect(v: String) { _swipeEffect.value = v; sp.edit().putString("swipeEffect", v).apply() }

    var knownFolders: Set<String>
        get() = readSet("knownFolders")
        set(value) { sp.edit().putStringSet("knownFolders", HashSet(value)).apply() }

    var dropboxCredential: String?
        get() = sp.getString("dbxCred", null)
        set(value) { sp.edit().putString("dbxCred", value).apply() }

    @Synchronized
    fun updateHiddenPhotos(change: (Set<String>) -> Set<String>) {
        val v = change(_hiddenPhotos.value)
        _hiddenPhotos.value = v
        sp.edit().putStringSet("hiddenPhotos", HashSet(v)).apply()
    }

    @Synchronized
    fun updateHiddenFolders(change: (Set<String>) -> Set<String>) {
        val v = change(_hiddenFolders.value)
        _hiddenFolders.value = v
        sp.edit().putStringSet("hiddenFolders", HashSet(v)).apply()
    }

    @Synchronized
    fun updateFavorites(change: (Set<String>) -> Set<String>) {
        val v = change(_favorites.value)
        _favorites.value = v
        sp.edit().putStringSet("favorites", HashSet(v)).apply()
    }

    fun setAutoShowNew(v: Boolean) {
        _autoShowNew.value = v
        sp.edit().putBoolean("autoShowNew", v).apply()
    }

    fun setLockHidden(v: Boolean) {
        _lockHidden.value = v
        sp.edit().putBoolean("lockHidden", v).apply()
    }

    fun setColumns(v: Int) {
        _columns.value = v
        sp.edit().putInt("columns", v).apply()
    }
}
