@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package se.krill.fotobacken.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Animation
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Home
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NewReleases
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemColors
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import se.krill.fotobacken.BuildConfig

private val itemColors: ListItemColors
    @Composable get() = ListItemDefaults.colors(containerColor = Color.Transparent)

@Composable
fun SettingsScreen(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    val hiddenList by vm.hiddenPhotoList.collectAsStateWithLifecycle()
    val lock by vm.prefs.lockHidden.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val connected by vm.dropboxConnected.collectAsStateWithLifecycle()
    val themeId by vm.prefs.theme.collectAsStateWithLifecycle()
    val mode by vm.prefs.mode.collectAsStateWithLifecycle()
    val startTab by vm.prefs.startTab.collectAsStateWithLifecycle()
    val dark = useDarkMode(mode)
    val groupPhotos by vm.prefs.groupPhotos.collectAsStateWithLifecycle()
    val groupFolders by vm.prefs.groupFolders.collectAsStateWithLifecycle()
    val effect by vm.prefs.swipeEffect.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    var easterEgg by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Inställningar") }, navigationIcon = { BackButton { vm.pop() } })
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            SectionTitle("Utseende")
            ListItem(
                headlineContent = { Text("Läge") },
                supportingContent = { Text("System följer mobilens inställning") },
                leadingContent = { Icon(Icons.Outlined.DarkMode, null) },
                colors = itemColors,
            )
            ChipRow(
                options = listOf("system" to "System", "ljust" to "Ljust", "morkt" to "Mörkt"),
                selected = mode,
                onSelect = { vm.prefs.setMode(it) },
            )
            ListItem(
                headlineContent = { Text("Färgtema") },
                supportingContent = { Text(themeById(themeId).name) },
                leadingContent = { Icon(Icons.Outlined.Palette, null) },
                colors = itemColors,
            )
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                appThemes.forEach { t ->
                    ThemeSwatch(t, dark = dark, selected = t.id == themeId) { vm.prefs.setTheme(t.id) }
                }
            }
            ListItem(
                headlineContent = { Text("Bläddringseffekt") },
                supportingContent = { Text("Animation när du sveper mellan bilder") },
                leadingContent = { Icon(Icons.Outlined.Animation, null) },
                colors = itemColors,
            )
            ChipRow(
                options = listOf("av" to "Av", "mjuk" to "Mjuk", "kub" to "Kub", "stapel" to "Stapel"),
                selected = effect,
                onSelect = { vm.prefs.setSwipeEffect(it) },
            )
            ListItem(
                headlineContent = { Text("Dela upp Bilder efter månad") },
                leadingContent = { Icon(Icons.Outlined.CalendarMonth, null) },
                trailingContent = { Switch(checked = groupPhotos, onCheckedChange = { vm.prefs.setGroupPhotos(it) }) },
                colors = itemColors,
            )
            ListItem(
                headlineContent = { Text("Dela upp mappar efter månad") },
                supportingContent = { Text("Går också att ändra med kalenderknappen i en mapp") },
                leadingContent = { Icon(Icons.Outlined.CalendarMonth, null) },
                trailingContent = { Switch(checked = groupFolders, onCheckedChange = { vm.prefs.setGroupFolders(it) }) },
                colors = itemColors,
            )

            SectionTitle("Galleri")
            ListItem(
                headlineContent = { Text("Starta i") },
                supportingContent = { Text("Fliken som visas när appen öppnas") },
                leadingContent = { Icon(Icons.Outlined.Home, null) },
                colors = itemColors,
            )
            ChipRow(
                options = listOf("bilder" to "Bilder", "mappar" to "Mappar", "dropbox" to "Dropbox"),
                selected = startTab,
                onSelect = { vm.prefs.setStartTab(it) },
            )
            ListItem(
                headlineContent = { Text("Mappar som visas") },
                supportingContent = { Text("Välj vilka mappar som syns i galleriet") },
                leadingContent = { Icon(Icons.Outlined.FolderOpen, null) },
                trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) },
                colors = itemColors,
                modifier = Modifier.clickable { vm.push(Screen.FolderSettings) },
            )
            ListItem(
                headlineContent = { Text("Dolda bilder") },
                supportingContent = { Text(bilder(hiddenList.size)) },
                leadingContent = { Icon(Icons.Outlined.VisibilityOff, null) },
                trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) },
                colors = itemColors,
                modifier = Modifier.clickable {
                    val activity = ctx.findActivity()
                    if (lock && activity != null) unlock(activity) { vm.push(Screen.Hidden) }
                    else vm.push(Screen.Hidden)
                },
            )
            ListItem(
                headlineContent = { Text("Lås dolda bilder") },
                supportingContent = { Text("Kräv fingeravtryck eller PIN för att se dem") },
                leadingContent = { Icon(Icons.Outlined.Fingerprint, null) },
                trailingContent = { Switch(checked = lock, onCheckedChange = { vm.prefs.setLockHidden(it) }) },
                colors = itemColors,
            )
            ListItem(
                headlineContent = { Text("Bilder per rad") },
                leadingContent = { Icon(Icons.Outlined.GridView, null) },
                trailingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(3, 4, 5).forEach { n ->
                            FilterChip(
                                selected = cols == n,
                                onClick = { vm.prefs.setColumns(n) },
                                label = { Text("$n") },
                            )
                        }
                    }
                },
                colors = itemColors,
            )

            SectionTitle("Dropbox")
            when {
                !vm.dropboxConfigured -> ListItem(
                    headlineContent = { Text("Inte inställt") },
                    supportingContent = { Text("Den här versionen är byggd utan Dropbox-nyckel") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null) },
                    colors = itemColors,
                )
                connected -> ListItem(
                    headlineContent = { Text("Ansluten") },
                    supportingContent = { Text("Appen kan läsa dina bilder i Dropbox") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = { TextButton(onClick = { vm.disconnectDropbox() }) { Text("Koppla från") } },
                    colors = itemColors,
                )
                else -> ListItem(
                    headlineContent = { Text("Inte ansluten") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null) },
                    trailingContent = {
                        TextButton(onClick = { vm.startDropboxAuth(ctx.findActivity() ?: ctx) }) { Text("Anslut") }
                    },
                    colors = itemColors,
                )
            }

            SectionTitle("Om")
            ListItem(
                headlineContent = { Text("Fotobacken") },
                supportingContent = { Text("Version ${BuildConfig.VERSION_NAME}") },
                leadingContent = { Icon(Icons.Outlined.Info, null) },
                colors = itemColors,
                modifier = Modifier.combinedClickable(
                    onClick = {},
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        easterEgg = true
                    },
                ),
            )
            Spacer(Modifier.height(24.dp))
        }
    }
    if (easterEgg) HeartEasterEgg { easterEgg = false }
    }
}

@Composable
private fun ChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (id, name) ->
            FilterChip(selected = selected == id, onClick = { onSelect(id) }, label = { Text(name) })
        }
    }
}

@Composable
private fun ThemeSwatch(theme: AppTheme, dark: Boolean, selected: Boolean, onClick: () -> Unit) {
    val scheme = if (dark) theme.dark else theme.light
    val ring = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(64.dp)
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .size(48.dp)
                .border(if (selected) 3.dp else 1.dp, ring, CircleShape)
                .padding(5.dp)
                .background(scheme.background, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(22.dp)
                    .background(scheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) Icon(Icons.Filled.Check, null, tint = scheme.onPrimary, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(theme.name, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
fun FolderSettingsScreen(vm: GalleryViewModel) {
    val folders by vm.allFolders.collectAsStateWithLifecycle()
    val hidden by vm.prefs.hiddenFolders.collectAsStateWithLifecycle()
    val auto by vm.prefs.autoShowNew.collectAsStateWithLifecycle()
    val hasPerm by vm.hasPermission.collectAsStateWithLifecycle()
    val dbxHidden = hidden.filter { it.startsWith("df:") }.sorted()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Mappar som visas") }, navigationIcon = { BackButton { vm.pop() } })
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item {
                ListItem(
                    headlineContent = { Text("Visa nya mappar automatiskt") },
                    supportingContent = { Text("Annars är nya mappar dolda tills du slår på dem här") },
                    leadingContent = { Icon(Icons.Outlined.NewReleases, null) },
                    trailingContent = { Switch(checked = auto, onCheckedChange = { vm.prefs.setAutoShowNew(it) }) },
                    colors = itemColors,
                )
            }
            item {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    SectionTitle("På mobilen", Modifier.weight(1f))
                    if (folders.isNotEmpty()) {
                        TextButton(onClick = {
                            vm.prefs.updateHiddenFolders { set -> set.filterNot { it.startsWith("lf:") }.toSet() }
                        }) { Text("Visa alla") }
                        TextButton(onClick = {
                            vm.prefs.updateHiddenFolders { set -> set + folders.map { it.key } }
                        }) { Text("Dölj alla") }
                    }
                }
            }
            if (!hasPerm) {
                item {
                    Text(
                        "Appen har inte tillgång till bilderna på mobilen än.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
            items(folders, key = { it.key }) { f ->
                val visible = f.key !in hidden
                ListItem(
                    headlineContent = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        val parts = buildList {
                            if (f.onSdCard) add("SD-kort")
                            add(bilder(f.count))
                            f.location?.takeIf { it.isNotBlank() }?.let { add(it) }
                        }
                        Text(parts.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    leadingContent = {
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            f.cover?.let {
                                AsyncImage(
                                    model = it.thumb,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    },
                    trailingContent = {
                        Switch(checked = visible, onCheckedChange = { vm.setFolderHidden(f.key, !it) })
                    },
                    colors = itemColors,
                    modifier = Modifier.clickable { vm.setFolderHidden(f.key, visible) },
                )
            }
            item { SectionTitle("Dolda Dropbox-mappar") }
            if (dbxHidden.isEmpty()) {
                item {
                    Text(
                        "Inga. Dölj en Dropbox-mapp genom att hålla in den i Dropbox-fliken.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
            items(dbxHidden, key = { it }) { k ->
                val path = k.removePrefix("df:")
                ListItem(
                    headlineContent = { Text(path.substringAfterLast('/').ifEmpty { "Dropbox" }) },
                    supportingContent = { Text(path, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = { TextButton(onClick = { vm.setFolderHidden(k, false) }) { Text("Visa igen") } },
                    colors = itemColors,
                )
            }
            item { Box(Modifier.padding(bottom = 32.dp)) }
        }
    }
}
