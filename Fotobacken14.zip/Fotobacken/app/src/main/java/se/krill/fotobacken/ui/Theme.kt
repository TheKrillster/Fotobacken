package se.krill.fotobacken.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

data class AppTheme(val id: String, val name: String, val dark: ColorScheme, val light: ColorScheme)

private fun dark(
    primary: Long, bg: Long, variant: Long, container: Long, onContainer: Long,
    onSurface: Long, onVariant: Long, onPrimary: Long = 0xFF141414,
): ColorScheme {
    val b = Color(bg)
    val v = Color(variant)
    return darkColorScheme(
        primary = Color(primary), onPrimary = Color(onPrimary),
        primaryContainer = Color(container), onPrimaryContainer = Color(onContainer),
        secondary = Color(primary), onSecondary = Color(onPrimary),
        secondaryContainer = Color(container), onSecondaryContainer = Color(onContainer),
        tertiary = Color(primary),
        background = b, onBackground = Color(onSurface),
        surface = b, onSurface = Color(onSurface),
        surfaceVariant = v, onSurfaceVariant = Color(onVariant),
        surfaceContainerLowest = b, surfaceContainerLow = b,
        surfaceContainer = lerp(b, v, 0.5f),
        surfaceContainerHigh = v, surfaceContainerHighest = v,
        outline = Color(onVariant).copy(alpha = 0.6f), outlineVariant = v,
    )
}

private fun light(
    primary: Long, bg: Long, variant: Long, container: Long, onContainer: Long,
    onSurface: Long, onVariant: Long, onPrimary: Long = 0xFFFFFFFF,
): ColorScheme {
    val b = Color(bg)
    val v = Color(variant)
    return lightColorScheme(
        primary = Color(primary), onPrimary = Color(onPrimary),
        primaryContainer = Color(container), onPrimaryContainer = Color(onContainer),
        secondary = Color(primary), onSecondary = Color(onPrimary),
        secondaryContainer = Color(container), onSecondaryContainer = Color(onContainer),
        tertiary = Color(primary),
        background = b, onBackground = Color(onSurface),
        surface = b, onSurface = Color(onSurface),
        surfaceVariant = v, onSurfaceVariant = Color(onVariant),
        surfaceContainerLowest = Color.White, surfaceContainerLow = lerp(b, v, 0.25f),
        surfaceContainer = lerp(b, v, 0.5f),
        surfaceContainerHigh = lerp(b, v, 0.75f), surfaceContainerHighest = v,
        outline = Color(onVariant).copy(alpha = 0.7f), outlineVariant = v,
    )
}

val appThemes: List<AppTheme> = listOf(
    AppTheme(
        "barnsten", "Bärnsten",
        dark(0xFFE8A33D, 0xFF16130F, 0xFF2A241D, 0xFF4A3414, 0xFFFFDDB0, 0xFFEDE3D4, 0xFFBFB2A0, 0xFF241605),
        light(0xFF9A5B00, 0xFFFBF8F3, 0xFFEFE8DD, 0xFFFFDDB0, 0xFF2E1800, 0xFF1F1B16, 0xFF50463A),
    ),
    AppTheme(
        "hav", "Hav",
        dark(0xFF5DB3E8, 0xFF0E1418, 0xFF1E2A32, 0xFF14354A, 0xFFCDEBFF, 0xFFE2ECF2, 0xFFA7B8C3, 0xFF04202F),
        light(0xFF00658F, 0xFFF6FAFD, 0xFFDDE8EF, 0xFFC6E7FF, 0xFF001E2E, 0xFF171C1F, 0xFF41484D),
    ),
    AppTheme(
        "skog", "Skog",
        dark(0xFF7CC48A, 0xFF101511, 0xFF1F2A21, 0xFF1F3D26, 0xFFCFF2D6, 0xFFE3EDE4, 0xFFAABBAD, 0xFF062410),
        light(0xFF2E6B3A, 0xFFF6FBF3, 0xFFDEE8DB, 0xFFB1F1BA, 0xFF00210A, 0xFF181D18, 0xFF414941),
    ),
    AppTheme(
        "lavendel", "Lavendel",
        dark(0xFFB39DFF, 0xFF131119, 0xFF252131, 0xFF33295A, 0xFFE6DDFF, 0xFFEAE6F2, 0xFFB6AFC6, 0xFF1C1040),
        light(0xFF6750A4, 0xFFFBF8FF, 0xFFE7E0EC, 0xFFE9DDFF, 0xFF22005D, 0xFF1C1B1F, 0xFF49454F),
    ),
    AppTheme(
        "hallon", "Hallon",
        dark(0xFFF2789F, 0xFF171012, 0xFF2C1F24, 0xFF4D1F30, 0xFFFFD9E3, 0xFFF2E5E8, 0xFFC7AEB5, 0xFF3A0718),
        light(0xFFA8355C, 0xFFFFF8F8, 0xFFF3DDE1, 0xFFFFD9E0, 0xFF3F0019, 0xFF201A1B, 0xFF524345),
    ),
    AppTheme(
        "natt", "Svartvit",
        dark(0xFFEDEDED, 0xFF000000, 0xFF1A1A1A, 0xFF2C2C2C, 0xFFFFFFFF, 0xFFF0F0F0, 0xFFA0A0A0, 0xFF000000),
        light(0xFF1F1F1F, 0xFFFFFFFF, 0xFFEAEAEA, 0xFFDDDDDD, 0xFF111111, 0xFF111111, 0xFF555555),
    ),
)

fun themeById(id: String): AppTheme = appThemes.firstOrNull { it.id == id } ?: appThemes.first()

/** Avgör om appen ska vara mörk utifrån valt läge. */
@Composable
fun useDarkMode(mode: String): Boolean = when (mode) {
    "ljust" -> false
    "morkt" -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun FotobackenTheme(themeId: String, dark: Boolean, content: @Composable () -> Unit) {
    val t = themeById(themeId)
    MaterialTheme(colorScheme = if (dark) t.dark else t.light, content = content)
}
