@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package se.krill.fotobacken.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.ImageNotSupported
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import se.krill.fotobacken.data.DbxFolder
import se.krill.fotobacken.data.Folder
import se.krill.fotobacken.data.Permissions

@Composable
fun MainTabs(vm: GalleryViewModel, active: Boolean) {
    val ctx = LocalContext.current
    var selection by remember { mutableStateOf(emptySet<String>()) }
    val photosGrid = rememberLazyGridState()
    val foldersGrid = rememberLazyGridState()
    val hiddenPhotos by vm.prefs.hiddenPhotos.collectAsStateWithLifecycle()
    val currentDbxPath = vm.dbxPath.lastOrNull() ?: ""

    LaunchedEffect(vm.tab, currentDbxPath) {
        selection = emptySet()
        if (vm.tab != Tab.Folders) vm.sortingFolders = false
    }
    BackHandler(enabled = active && vm.sortingFolders) { vm.sortingFolders = false }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshLocal()
    }
    val requestPermission = { launcher.launch(Permissions.toRequest()) }
    val openAppSettings = {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
        )
    }

    val toggle: (String) -> Unit = { k -> selection = if (k in selection) selection - k else selection + k }

    SelectionScaffold(
        vm = vm,
        selection = selection,
        onSelectionChange = { selection = it },
        active = active,
        allKeys = {
            when (vm.tab) {
                Tab.Photos -> vm.visiblePhotos.value.map { it.key }
                Tab.Dropbox -> (vm.dbxListings[currentDbxPath] as? DbxListing.Ready)
                    ?.content?.photos?.map { it.key }?.filter { it !in hiddenPhotos } ?: emptyList()
                Tab.Folders -> emptyList()
            }
        },
        topBar = {
            val inSubfolder = vm.tab == Tab.Dropbox && vm.dbxPath.size > 1
            if (vm.tab == Tab.Folders && vm.sortingFolders) {
                TopAppBar(
                    title = { Text("Sortera mappar") },
                    navigationIcon = {
                        IconButton(onClick = { vm.sortingFolders = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Klar")
                        }
                    },
                    actions = {
                        TextButton(onClick = { vm.resetFolderOrder() }) { Text("Återställ") }
                        TextButton(onClick = { vm.sortingFolders = false }) { Text("Klar") }
                    },
                )
                return@SelectionScaffold
            }
            TopAppBar(
                title = {
                    Text(
                        when (vm.tab) {
                            Tab.Photos -> "Fotobacken"
                            Tab.Folders -> "Mappar"
                            Tab.Dropbox -> if (inSubfolder) currentDbxPath.substringAfterLast('/') else "Dropbox"
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    if (inSubfolder) BackButton { vm.dropboxUp() }
                },
                actions = {
                    if (vm.tab == Tab.Folders) {
                        IconButton(onClick = { vm.sortingFolders = true }) {
                            Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sortera mappar")
                        }
                    }
                    IconButton(onClick = { vm.refresh() }) { Icon(Icons.Filled.Refresh, contentDescription = "Uppdatera") }
                    IconButton(onClick = { vm.push(Screen.Settings) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Inställningar")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = vm.tab == Tab.Photos,
                    onClick = { vm.tab = Tab.Photos },
                    icon = { Icon(if (vm.tab == Tab.Photos) Icons.Filled.PhotoLibrary else Icons.Outlined.PhotoLibrary, null) },
                    label = { Text("Bilder") },
                )
                NavigationBarItem(
                    selected = vm.tab == Tab.Folders,
                    onClick = { vm.tab = Tab.Folders },
                    icon = { Icon(if (vm.tab == Tab.Folders) Icons.Filled.Folder else Icons.Outlined.Folder, null) },
                    label = { Text("Mappar") },
                )
                NavigationBarItem(
                    selected = vm.tab == Tab.Dropbox,
                    onClick = { vm.tab = Tab.Dropbox },
                    icon = { Icon(Icons.Filled.Cloud, null) },
                    label = { Text("Dropbox") },
                )
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val hasPerm by vm.hasPermission.collectAsStateWithLifecycle()
            when (vm.tab) {
                Tab.Photos, Tab.Folders -> {
                    if (!hasPerm) {
                        CenterMessage(
                            icon = Icons.Outlined.PhotoLibrary,
                            title = "Ge Fotobacken tillgång till bilderna",
                            text = "Appen behöver läsa bilderna på mobilen och minneskortet för att kunna visa dem.",
                            action = "Ge åtkomst" to requestPermission,
                            secondary = "Öppna appinställningar" to openAppSettings,
                        )
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            PartialAccessBanner(vm, requestPermission)
                            if (vm.tab == Tab.Photos) {
                                PhotosTab(vm, selection, toggle, photosGrid)
                            } else {
                                FoldersTab(vm, foldersGrid)
                            }
                        }
                    }
                }
                Tab.Dropbox -> DropboxTab(vm, selection, toggle, active)
            }
        }
    }
}

@Composable
private fun PartialAccessBanner(vm: GalleryViewModel, onRequest: () -> Unit) {
    val partial by vm.partialAccess.collectAsStateWithLifecycle()
    if (!partial) return
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Appen ser bara de bilder du har valt.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onRequest) { Text("Ändra") }
        }
    }
}

@Composable
private fun PhotosTab(
    vm: GalleryViewModel,
    selection: Set<String>,
    onToggle: (String) -> Unit,
    state: androidx.compose.foundation.lazy.grid.LazyGridState,
) {
    val photos by vm.visiblePhotos.collectAsStateWithLifecycle()
    val loaded by vm.localLoaded.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val favorites by vm.prefs.favorites.collectAsStateWithLifecycle()
    val grouped by vm.prefs.groupPhotos.collectAsStateWithLifecycle()
    val entries = remember(photos, grouped) { if (grouped) groupByMonth(photos) else flatEntries(photos) }
    when {
        !loaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        photos.isEmpty() -> CenterMessage(
            icon = Icons.Outlined.ImageNotSupported,
            title = "Inga bilder att visa",
            text = "Hittar inga bilder, eller så är alla mappar dolda. Mapparna väljer du under Inställningar.",
        )
        else -> PhotoGrid(
            entries = entries,
            columns = cols,
            selection = selection,
            onOpen = { i -> vm.push(Screen.Viewer(photos, i)) },
            onToggle = onToggle,
            state = state,
            favorites = favorites,
        )
    }
}

@Composable
private fun FoldersTab(vm: GalleryViewModel, state: androidx.compose.foundation.lazy.grid.LazyGridState) {
    val folders by vm.folders.collectAsStateWithLifecycle()
    val favs by vm.favoritePhotoList.collectAsStateWithLifecycle()
    val loaded by vm.localLoaded.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<Folder?>(null) }
    val sorting = vm.sortingFolders
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // Arbetskopia som ändras medan man drar, sparas när man släpper.
    var working by remember { mutableStateOf(folders) }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(folders) { if (draggingKey == null) working = folders }

    fun itemAt(p: Offset) = state.layoutInfo.visibleItemsInfo.firstOrNull {
        p.x >= it.offset.x && p.x <= it.offset.x + it.size.width &&
            p.y >= it.offset.y && p.y <= it.offset.y + it.size.height
    }

    fun endDrag() {
        if (draggingKey != null) vm.saveFolderOrder(working.map { it.key })
        draggingKey = null
        dragOffset = Offset.Zero
    }

    when {
        !loaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        folders.isEmpty() && working.isEmpty() && favs.isEmpty() -> CenterMessage(
            icon = Icons.Outlined.Folder,
            title = "Inga mappar att visa",
            text = "Alla mappar är dolda eller tomma. Välj vilka som visas under Inställningar › Mappar som visas.",
        )
        else -> LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            state = state,
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(sorting) {
                    if (!sorting) return@pointerInput
                    detectDragGesturesAfterLongPress(
                        onDragStart = { pos ->
                            val k = itemAt(pos)?.key as? String
                            if (k != null && k != "favoriter" && k != "tips") {
                                draggingKey = k
                                dragOffset = Offset.Zero
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        },
                        onDrag = { change, amount ->
                            val k = draggingKey ?: return@detectDragGesturesAfterLongPress
                            change.consume()
                            dragOffset += amount
                            val info = state.layoutInfo
                            val cur = info.visibleItemsInfo.firstOrNull { it.key == k } ?: return@detectDragGesturesAfterLongPress
                            val center = Offset(
                                cur.offset.x + cur.size.width / 2f + dragOffset.x,
                                cur.offset.y + cur.size.height / 2f + dragOffset.y,
                            )
                            val target = itemAt(center)
                            val tk = target?.key as? String
                            if (target != null && tk != null && tk != k && tk != "favoriter" && tk != "tips") {
                                val from = working.indexOfFirst { it.key == k }
                                val to = working.indexOfFirst { it.key == tk }
                                if (from >= 0 && to >= 0) {
                                    working = working.toMutableList().apply { add(to, removeAt(from)) }
                                    // Håll kortet under fingret när det byter plats.
                                    dragOffset += Offset(
                                        (cur.offset.x - target.offset.x).toFloat(),
                                        (cur.offset.y - target.offset.y).toFloat(),
                                    )
                                }
                            }
                            // Scrolla när man drar nära kanten.
                            val edge = 120f
                            val step = when {
                                center.y > info.viewportEndOffset - edge -> 18f
                                center.y < info.viewportStartOffset + edge -> -18f
                                else -> 0f
                            }
                            if (step != 0f) scope.launch {
                                val moved = state.scrollBy(step)
                                dragOffset += Offset(0f, moved)
                            }
                        },
                        onDragEnd = { endDrag() },
                        onDragCancel = { endDrag() },
                    )
                },
        ) {
            if (sorting) {
                item(key = "tips", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "Håll in en mapp och dra den dit du vill ha den.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    )
                }
            }
            if (favs.isNotEmpty()) {
                item(key = "favoriter") {
                    FolderCard(
                        folder = Folder("favoriter", "Favoriter", favs.size, favs.first(), false, null),
                        favorite = true,
                        clickable = !sorting,
                        onClick = { vm.push(Screen.Favorites) },
                        onLongClick = {},
                        modifier = Modifier.animateItem(),
                    )
                }
            }
            items(working, key = { it.key }) { f ->
                val dragging = f.key == draggingKey
                FolderCard(
                    folder = f,
                    clickable = !sorting,
                    showHandle = sorting,
                    onClick = { vm.push(Screen.Folder(f.key, f.name)) },
                    onLongClick = { confirm = f },
                    modifier = if (dragging) {
                        Modifier
                            .zIndex(1f)
                            .graphicsLayer {
                                translationX = dragOffset.x
                                translationY = dragOffset.y
                                scaleX = 1.06f
                                scaleY = 1.06f
                                shadowElevation = 16f
                            }
                    } else {
                        Modifier.animateItem()
                    },
                )
            }
        }
    }

    confirm?.let { f ->
        HideFolderDialog(
            name = f.name,
            onConfirm = {
                vm.setFolderHidden(f.key, true)
                confirm = null
            },
            onDismiss = { confirm = null },
        )
    }
}

@Composable
fun HideFolderDialog(name: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dölj mappen?") },
        text = {
            Text("”$name” visas inte längre i galleriet. Du kan visa den igen under Inställningar › Mappar som visas.")
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Dölj") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Avbryt") } },
    )
}

@Composable
private fun FolderCard(
    folder: Folder,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    favorite: Boolean = false,
    clickable: Boolean = true,
    showHandle: Boolean = false,
) {
    Column(
        modifier.then(
            if (clickable) Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick) else Modifier
        )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            folder.cover?.let {
                AsyncImage(
                    model = it.thumb,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            if (favorite) {
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(22.dp),
                )
            }
            if (showHandle) {
                Surface(
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp),
                ) {
                    Icon(
                        Icons.Filled.DragIndicator,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(4.dp).size(20.dp),
                    )
                }
            }
            if (folder.onSdCard) {
                Surface(
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.75f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                ) {
                    Row(Modifier.padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.SdCard, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(3.dp))
                        Text("SD", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        Text(
            folder.name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp),
        )
        Text(
            bilder(folder.count),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 2.dp),
        )
    }
}

@Composable
private fun DropboxTab(
    vm: GalleryViewModel,
    selection: Set<String>,
    onToggle: (String) -> Unit,
    active: Boolean,
) {
    val ctx = LocalContext.current
    val connected by vm.dropboxConnected.collectAsStateWithLifecycle()
    val hiddenPhotos by vm.prefs.hiddenPhotos.collectAsStateWithLifecycle()
    val hiddenFolders by vm.prefs.hiddenFolders.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val favorites by vm.prefs.favorites.collectAsStateWithLifecycle()
    val path = vm.dbxPath.lastOrNull() ?: ""
    var confirm by remember { mutableStateOf<DbxFolder?>(null) }

    BackHandler(enabled = active && selection.isEmpty() && vm.dbxPath.size > 1) { vm.dropboxUp() }
    LaunchedEffect(path, connected) { if (connected) vm.loadDropbox(path) }

    if (!vm.dropboxConfigured) {
        CenterMessage(
            icon = Icons.Outlined.CloudOff,
            title = "Dropbox är inte inställt än",
            text = "Appen behöver en nyckel från Dropbox som läggs in när appen byggs. Den här versionen saknar nyckel.",
        )
        return
    }
    if (!connected) {
        CenterMessage(
            icon = Icons.Filled.Cloud,
            title = "Anslut Dropbox",
            text = "Logga in på ditt Dropbox-konto för att bläddra bland bilderna där. Appen kan bara läsa, aldrig ändra eller radera.",
            action = "Anslut Dropbox" to { vm.startDropboxAuth(ctx.findActivity() ?: ctx) },
        )
        return
    }

    when (val l = vm.dbxListings[path]) {
        null, DbxListing.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        is DbxListing.Failed -> CenterMessage(
            icon = Icons.Outlined.ErrorOutline,
            title = "Något gick fel",
            text = l.message,
            action = "Försök igen" to { vm.loadDropbox(path, force = true) },
        )
        is DbxListing.Ready -> {
            val folders = remember(l, hiddenFolders) { l.content.folders.filter { "df:${it.path}" !in hiddenFolders } }
            val photos = remember(l, hiddenPhotos) { l.content.photos.filter { it.key !in hiddenPhotos } }
            val entries = remember(photos) { flatEntries(photos) }
            if (folders.isEmpty() && photos.isEmpty()) {
                CenterMessage(
                    icon = Icons.Outlined.Folder,
                    title = "Inga bilder här",
                    text = "Mappen har inga bilder eller undermappar att visa.",
                )
            } else {
                PhotoGrid(
                    entries = entries,
                    columns = cols,
                    selection = selection,
                    onOpen = { i -> vm.push(Screen.Viewer(photos, i)) },
                    onToggle = onToggle,
                    state = rememberLazyGridState(),
                    favorites = favorites,
                    topContent = {
                        items(
                            items = folders,
                            key = { "f:" + it.path },
                            span = { GridItemSpan(maxLineSpan) },
                            contentType = { 2 },
                        ) { f ->
                            DropboxFolderRow(
                                folder = f,
                                onClick = { vm.openDropboxFolder(f.path) },
                                onLongClick = { confirm = f },
                            )
                        }
                    },
                )
            }
        }
    }

    confirm?.let { f ->
        HideFolderDialog(
            name = f.name,
            onConfirm = {
                vm.setFolderHidden("df:${f.path}", true)
                confirm = null
            },
            onDismiss = { confirm = null },
        )
    }
}

@Composable
private fun DropboxFolderRow(folder: DbxFolder, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Text(folder.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
