package se.krill.fotobacken

import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import se.krill.fotobacken.ui.useDarkMode
import se.krill.fotobacken.ui.AppRoot
import se.krill.fotobacken.ui.FotobackenTheme
import se.krill.fotobacken.ui.GalleryViewModel

class MainActivity : FragmentActivity() {
    private val vm: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            val themeId by vm.prefs.theme.collectAsStateWithLifecycle()
            val mode by vm.prefs.mode.collectAsStateWithLifecycle()
            val dark = useDarkMode(mode)
            val light = !dark
            LaunchedEffect(light) {
                // Mörka ikoner i statusraden för det ljusa temat.
                if (light) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                        navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    )
                } else {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
                        navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
                    )
                }
            }
            FotobackenTheme(themeId, dark) { AppRoot(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
        vm.checkDropboxAuthResult()
    }

    override fun onStop() {
        super.onStop()
        vm.closeHiddenScreens()
    }
}
