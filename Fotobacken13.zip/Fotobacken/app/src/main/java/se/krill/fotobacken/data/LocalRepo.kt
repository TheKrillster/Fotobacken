package se.krill.fotobacken.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

/** Läser alla bilder på mobilen och minneskortet via MediaStore. */
object LocalRepo {

    @Suppress("DEPRECATION")
    fun load(ctx: Context): List<Photo> {
        val q = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val collection = if (q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val cols = mutableListOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
        )
        if (q) {
            cols.add(MediaStore.Images.Media.VOLUME_NAME)
            cols.add(MediaStore.Images.Media.RELATIVE_PATH)
        } else {
            cols.add(MediaStore.Images.Media.DATA)
        }

        val primaryRoot = Environment.getExternalStorageDirectory().absolutePath
        val out = ArrayList<Photo>()
        ctx.contentResolver.query(
            collection, cols.toTypedArray(), null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val iBucket = c.getColumnIndex(MediaStore.Images.Media.BUCKET_ID)
            val iBucketName = c.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val iName = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
            val iTaken = c.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
            val iAdded = c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
            val iSize = c.getColumnIndex(MediaStore.Images.Media.SIZE)
            val iW = c.getColumnIndex(MediaStore.Images.Media.WIDTH)
            val iH = c.getColumnIndex(MediaStore.Images.Media.HEIGHT)
            val iVol = if (q) c.getColumnIndex(MediaStore.Images.Media.VOLUME_NAME) else -1
            val iRel = if (q) c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH) else -1
            val iData = if (!q) c.getColumnIndex(MediaStore.Images.Media.DATA) else -1

            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val vol: String = if (iVol >= 0) (c.getString(iVol) ?: "external") else "external"
                val uri = if (q) {
                    ContentUris.withAppendedId(MediaStore.Images.Media.getContentUri(vol), id)
                } else {
                    ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                }
                val bucket = (if (iBucket >= 0) c.getString(iBucket) else null) ?: "okand"
                val bucketName = (if (iBucketName >= 0) c.getString(iBucketName) else null) ?: "Okänd mapp"
                val taken = if (iTaken >= 0) c.getLong(iTaken) else 0L
                val added = if (iAdded >= 0) c.getLong(iAdded) * 1000L else 0L
                val data: String? = if (iData >= 0) c.getString(iData) else null
                val onSd = if (q) vol != MediaStore.VOLUME_EXTERNAL_PRIMARY && vol != "external"
                else data != null && !data.startsWith(primaryRoot)
                val location: String? = if (q) {
                    (if (iRel >= 0) c.getString(iRel) else null)?.trimEnd('/')
                } else {
                    data?.substringBeforeLast('/')?.removePrefix(primaryRoot)?.trimStart('/')
                }
                out.add(
                    Photo(
                        key = "l:$vol:$id",
                        thumb = if (q) LocalThumb(uri) else uri,
                        full = uri,
                        name = (if (iName >= 0) c.getString(iName) else null) ?: "bild",
                        folderKey = "lf:$bucket",
                        folderName = bucketName,
                        date = if (taken > 0) taken else added,
                        size = if (iSize >= 0) c.getLong(iSize) else 0L,
                        width = if (iW >= 0) c.getInt(iW) else 0,
                        height = if (iH >= 0) c.getInt(iH) else 0,
                        uri = uri,
                        onSdCard = onSd,
                        location = location,
                    )
                )
            }
        }
        out.sortByDescending { it.date }
        return out
    }
}
