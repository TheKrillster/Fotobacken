package se.krill.fotobacken.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

data class AppTheme(val id: String, val name: String, val scheme: ColorScheme, val light: Boolean = false)

private fun dark(
    primary: Long, bg: Long, variant: Long, container: Long, onContainer: Long,
    onSurface: Long, onVariant: Long, onPrimary: Long = 0xFF141414,
): ColorScheme {
    val b = Color(bg)
    val v = Color(variant)
    return darkColorScheme(
        primary = Color(primary),
        onPrimary = Color(onPrimary),
        primaryContainer = Color(container),
        onPrimaryContainer = Color(onContainer),
        secondary = Color(primary),
        onSecondary = Color(onPrimary),
        secondaryContainer = Color(container),
        onSecondaryContainer = Color(onContainer),
        tertiary = Color(primary),
        background = b,
        onBackground = Color(onSurface),
        surface = b,
        onSurface = Color(onSurface),
        surfaceVariant = v,
        onSurfaceVariant = Color(onVariant),
        surfaceContainerLowest = b,
        surfaceContainerLow = b,
        surfaceContainer = lerp(b, v, 0.5f),
        surfaceContainerHigh = v,
        surfaceContainerHighest = v,
        outline = Color(onVariant).copy(alpha = 0.6f),
        outlineVariant = v,
    )
}

val appThemes: List<AppTheme> = listOf(
    AppTheme("barnsten", "Bärnsten", dark(0xFFE8A33D, 0xFF16130F, 0xFF2A241D, 0xFF4A3414, 0xFFFFDDB0, 0xFFEDE3D4, 0xFFBFB2A0, 0xFF241605)),
    AppTheme("hav", "Hav", dark(0xFF5DB3E8, 0xFF0E1418, 0xFF1E2A32, 0xFF14354A, 0xFFCDEBFF, 0xFFE2ECF2, 0xFFA7B8C3, 0xFF04202F)),
    AppTheme("skog", "Skog", dark(0xFF7CC48A, 0xFF101511, 0xFF1F2A21, 0xFF1F3D26, 0xFFCFF2D6, 0xFFE3EDE4, 0xFFAABBAD, 0xFF062410)),
    AppTheme("lavendel", "Lavendel", dark(0xFFB39DFF, 0xFF131119, 0xFF252131, 0xFF33295A, 0xFFE6DDFF, 0xFFEAE6F2, 0xFFB6AFC6, 0xFF1C1040)),
    AppTheme("hallon", "Hallon", dark(0xFFF2789F, 0xFF171012, 0xFF2C1F24, 0xFF4D1F30, 0xFFFFD9E3, 0xFFF2E5E8, 0xFFC7AEB5, 0xFF3A0718)),
    AppTheme("natt", "Natt", dark(0xFFEDEDED, 0xFF000000, 0xFF1A1A1A, 0xFF2C2C2C, 0xFFFFFFFF, 0xFFF0F0F0, 0xFFA0A0A0, 0xFF000000)),
    AppTheme(
        "ljus", "Ljus",
        lightColorScheme(
            primary = Color(0xFF9A5B00),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFFFDDB0),
            onPrimaryContainer = Color(0xFF2E1800),
            secondary = Color(0xFF9A5B00),
            secondaryContainer = Color(0xFFFFDDB0),
            onSecondaryContainer = Color(0xFF2E1800),
            background = Color(0xFFFBF8F3),
            onBackground = Color(0xFF1F1B16),
            surface = Color(0xFFFBF8F3),
            onSurface = Color(0xFF1F1B16),
            surfaceVariant = Color(0xFFEFE8DD),
            onSurfaceVariant = Color(0xFF50463A),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF7F2EA),
            surfaceContainer = Color(0xFFF3EEE6),
            surfaceContainerHigh = Color(0xFFECE5DA),
            surfaceContainerHighest = Color(0xFFE6DED2),
            outline = Color(0xFF82766A),
            outlineVariant = Color(0xFFD5CABC),
        ),
        light = true,
    ),
)

fun themeById(id: String): AppTheme = appThemes.firstOrNull { it.id == id } ?: appThemes.first()

@Composable
fun FotobackenTheme(themeId: String, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = themeById(themeId).scheme, content = content)
}
