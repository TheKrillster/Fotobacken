package se.krill.fotobacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun AppRoot(vm: GalleryViewModel) {
    // Registreras först, så skärmarnas egna bakåt-hanterare går före när de är aktiva.
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.pop() }

    val top = vm.stack.lastOrNull()
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Flikarna ligger kvar under så att scrollpositionen sparas.
        MainTabs(vm, active = top == null)

        AnimatedContent(
            targetState = top,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                val viewer = targetState is Screen.Viewer || initialState is Screen.Viewer
                when {
                    // Bilden växer fram ur rutnätet och krymper tillbaka.
                    viewer && vm.navForward ->
                        (fadeIn(tween(200)) + scaleIn(tween(240), initialScale = 0.9f)) togetherWith
                            fadeOut(tween(160))
                    viewer ->
                        fadeIn(tween(160)) togetherWith
                            (fadeOut(tween(200)) + scaleOut(tween(220), targetScale = 0.9f))
                    // Övriga sidor glider in från höger.
                    vm.navForward ->
                        (slideInHorizontally(tween(260)) { it / 4 } + fadeIn(tween(220))) togetherWith
                            fadeOut(tween(180))
                    else ->
                        fadeIn(tween(180)) togetherWith
                            (slideOutHorizontally(tween(240)) { it / 4 } + fadeOut(tween(200)))
                }.using(null)
            },
            label = "skarm",
        ) { screen ->
            if (screen != null) {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    when (screen) {
                        is Screen.Folder -> FolderScreen(vm, screen)
                        is Screen.Viewer -> ViewerScreen(vm, screen)
                        is Screen.Settings -> SettingsScreen(vm)
                        is Screen.FolderSettings -> FolderSettingsScreen(vm)
                        is Screen.Hidden -> HiddenScreen(vm)
                        is Screen.Favorites -> FavoritesScreen(vm)
                    }
                }
            }
        }
    }
}
