package se.krill.fotobacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.sin
import kotlin.random.Random

private data class FloatingHeart(val x: Float, val delay: Float, val sizeDp: Int, val drift: Float, val color: Color)

/** Påskägget: ett bultande hjärta med små hjärtan som stiger. Tryck för att stänga. */
@Composable
fun HeartEasterEgg(onDismiss: () -> Unit) {
    BackHandler(onBack = onDismiss)

    val appear = remember { Animatable(0f) }
    val textIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(350)
        textIn.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    val inf = rememberInfiniteTransition(label = "hjarta")
    val beat = inf.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            keyframes {
                durationMillis = 1300
                1f at 0
                1.16f at 140
                1f at 300
                1.1f at 440
                1f at 680
            }
        ),
        label = "slag",
    )
    val rise = inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "stig",
    )

    val colors = listOf(Color(0xFFFF4F7E), Color(0xFFFF8FAB), Color(0xFFE8A33D), Color(0xFFFFC2D1))
    val hearts = remember {
        List(18) {
            FloatingHeart(
                x = Random.nextFloat(),
                delay = Random.nextFloat(),
                sizeDp = 12 + Random.nextInt(22),
                drift = Random.nextFloat() * 2f - 1f,
                color = colors[it % colors.size],
            )
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = appear.value.coerceIn(0f, 1f) }
            .background(Color.Black.copy(alpha = 0.78f))
            .pointerInput(Unit) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center,
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()
            hearts.forEach { p ->
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = p.color,
                    modifier = Modifier
                        .size(p.sizeDp.dp)
                        .graphicsLayer {
                            val t = (rise.value + p.delay) % 1f
                            translationX = p.x * w + sin(t * 9.4f) * p.drift * 60f
                            translationY = h * (1.05f - t * 1.15f)
                            rotationZ = p.drift * 30f
                            val s = 0.5f + 0.7f * (1f - t)
                            scaleX = s
                            scaleY = s
                            alpha = (1f - t) * 0.85f
                        },
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = null,
                tint = Color(0xFFFF4F7E),
                modifier = Modifier
                    .size(170.dp)
                    .graphicsLayer {
                        val s = appear.value * beat.value
                        scaleX = s
                        scaleY = s
                        rotationZ = (1f - appear.value.coerceIn(0f, 1f)) * -25f
                    },
            )
            Spacer(Modifier.height(28.dp))
            Text(
                "Love you, Elliott och Minna",
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer {
                    alpha = textIn.value
                    translationY = (1f - textIn.value) * 40f
                },
            )
        }
    }
}
