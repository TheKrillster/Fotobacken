package se.krill.fotobacken.data

import android.content.Context
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.key.Keyer
import coil.request.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okio.buffer
import okio.source

/** Låter Coil ladda Dropbox-bilder via Dropbox-SDK:n. */
class DropboxFetcher(
    private val ctx: Context,
    private val data: DropboxImage,
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        val file = withContext(Dispatchers.IO) { DropboxRepo.cachedFile(ctx, data) }
        return SourceResult(
            source = ImageSource(file.source().buffer(), ctx),
            mimeType = null,
            dataSource = DataSource.NETWORK,
        )
    }

    class Factory(private val ctx: Context) : Fetcher.Factory<DropboxImage> {
        override fun create(data: DropboxImage, options: Options, imageLoader: ImageLoader): Fetcher =
            DropboxFetcher(ctx, data)
    }
}

class DropboxKeyer : Keyer<DropboxImage> {
    override fun key(data: DropboxImage, options: Options): String =
        "dbx:${data.large}:${data.path.lowercase()}"
}
