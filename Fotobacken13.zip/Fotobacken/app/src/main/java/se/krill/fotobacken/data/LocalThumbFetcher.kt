package se.krill.fotobacken.data

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.util.Size
import androidx.annotation.RequiresApi
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.key.Keyer
import coil.request.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Hämtar färdiga miniatyrer från systemet – mycket snabbare än att avkoda hela bilden. */
@RequiresApi(Build.VERSION_CODES.Q)
class LocalThumbFetcher(private val ctx: Context, private val data: LocalThumb) : Fetcher {
    override suspend fun fetch(): FetchResult {
        val bmp = withContext(Dispatchers.IO) {
            ctx.contentResolver.loadThumbnail(data.uri, Size(384, 384), null)
        }
        return DrawableResult(
            drawable = BitmapDrawable(ctx.resources, bmp),
            isSampled = true,
            dataSource = DataSource.DISK,
        )
    }

    class Factory(private val ctx: Context) : Fetcher.Factory<LocalThumb> {
        override fun create(data: LocalThumb, options: Options, imageLoader: ImageLoader): Fetcher? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) LocalThumbFetcher(ctx, data) else null
    }
}

class LocalThumbKeyer : Keyer<LocalThumb> {
    override fun key(data: LocalThumb, options: Options): String = "lt:${data.uri}"
}
