package se.krill.fotobacken.data

import android.content.Context
import com.dropbox.core.DbxRequestConfig
import com.dropbox.core.oauth.DbxCredential
import com.dropbox.core.v2.DbxClientV2
import com.dropbox.core.v2.files.FileMetadata
import com.dropbox.core.v2.files.FolderMetadata
import com.dropbox.core.v2.files.ThumbnailFormat
import com.dropbox.core.v2.files.ThumbnailSize
import java.io.File
import java.io.IOException
import java.security.MessageDigest

object DropboxRepo {
    val config: DbxRequestConfig = DbxRequestConfig.newBuilder("Fotobacken/1.0").build()

    @Volatile
    var client: DbxClientV2? = null
        private set

    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")

    fun connect(cred: DbxCredential) {
        client = DbxClientV2(config, cred)
    }

    /** Kopplar från och tar bort nyckeln hos Dropbox. Körs på bakgrundstråd. */
    fun disconnect(ctx: Context) {
        val c = client
        client = null
        if (c != null) {
            try { c.auth().tokenRevoke() } catch (_: Exception) { }
        }
        File(ctx.cacheDir, "dbx-thumb").deleteRecursively()
        File(ctx.cacheDir, "dbx-full").deleteRecursively()
    }

    /** Listar en mapp. Rot = "". */
    fun list(path: String): DbxFolderContent {
        val c = client ?: throw IOException("Inte ansluten till Dropbox")
        var res = c.files().listFolder(path)
        val folders = ArrayList<DbxFolder>()
        val photos = ArrayList<Photo>()
        while (true) {
            for (m in res.entries) {
                if (m is FolderMetadata) {
                    folders.add(DbxFolder(m.name, m.pathDisplay ?: m.pathLower ?: "/${m.name}"))
                } else if (m is FileMetadata) {
                    if (m.name.substringAfterLast('.', "").lowercase() in imageExt) {
                        photos.add(toPhoto(m))
                    }
                }
            }
            if (!res.hasMore) break
            res = c.files().listFolderContinue(res.cursor)
        }
        folders.sortBy { it.name.lowercase() }
        photos.sortByDescending { it.date }
        return DbxFolderContent(folders, photos)
    }

    private fun toPhoto(m: FileMetadata): Photo {
        val path: String = m.pathDisplay ?: m.pathLower ?: "/${m.name}"
        val parent = path.substringBeforeLast('/', "")
        return Photo(
            key = "d:$path",
            thumb = DropboxImage(path, false),
            full = DropboxImage(path, true),
            name = m.name,
            folderKey = "df:$parent",
            folderName = parent.substringAfterLast('/').ifEmpty { "Dropbox" },
            date = m.clientModified?.time ?: 0L,
            size = m.size,
        )
    }

    /** Bygger en bild från en sparad nyckel, t.ex. för listan med dolda bilder. */
    fun photoFromKey(key: String): Photo {
        val path = key.removePrefix("d:")
        val parent = path.substringBeforeLast('/', "")
        return Photo(
            key = key,
            thumb = DropboxImage(path, false),
            full = DropboxImage(path, true),
            name = path.substringAfterLast('/'),
            folderKey = "df:$parent",
            folderName = parent.substringAfterLast('/').ifEmpty { "Dropbox" },
            date = 0L,
        )
    }

    /** Hämtar miniatyr eller originalbild till cachen och returnerar filen. */
    fun cachedFile(ctx: Context, img: DropboxImage): File {
        val dir = File(ctx.cacheDir, if (img.large) "dbx-full" else "dbx-thumb")
        dir.mkdirs()
        val target = File(dir, md5(img.path.lowercase()))
        if (target.exists() && target.length() > 0) return target
        val c = client ?: throw IOException("Inte ansluten till Dropbox")
        val tmp = File(dir, target.name + ".tmp")
        val downloader = if (img.large) {
            c.files().download(img.path)
        } else {
            c.files().getThumbnailBuilder(img.path)
                .withFormat(ThumbnailFormat.JPEG)
                .withSize(ThumbnailSize.W256H256)
                .start()
        }
        downloader.use { d -> tmp.outputStream().use { out -> d.download(out) } }
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        return target
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
