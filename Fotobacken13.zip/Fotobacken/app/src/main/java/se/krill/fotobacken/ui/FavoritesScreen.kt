@file:OptIn(ExperimentalMaterial3Api::class)

package se.krill.fotobacken.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FavoritesScreen(vm: GalleryViewModel) {
    val photos by vm.favoritePhotoList.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val entries = remember(photos) { flatEntries(photos) }
    var selection by remember { mutableStateOf(emptySet<String>()) }

    SelectionScaffold(
        vm = vm,
        selection = selection,
        onSelectionChange = { selection = it },
        allKeys = { photos.map { it.key } },
        topBar = {
            TopAppBar(
                title = { Text("Favoriter") },
                navigationIcon = { BackButton { vm.pop() } },
            )
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (photos.isEmpty()) {
                CenterMessage(
                    icon = Icons.Outlined.FavoriteBorder,
                    title = "Inga favoriter än",
                    text = "Tryck på hjärtat när du tittar på en bild, så hamnar den här.",
                )
            } else {
                PhotoGrid(
                    entries = entries,
                    columns = cols,
                    selection = selection,
                    onOpen = { i -> vm.push(Screen.Viewer(photos, i)) },
                    onToggle = { k -> selection = if (k in selection) selection - k else selection + k },
                )
            }
        }
    }
}
