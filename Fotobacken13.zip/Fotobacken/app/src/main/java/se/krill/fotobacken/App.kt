package se.krill.fotobacken

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import se.krill.fotobacken.data.DropboxFetcher
import se.krill.fotobacken.data.DropboxKeyer
import se.krill.fotobacken.data.LocalThumbFetcher
import se.krill.fotobacken.data.LocalThumbKeyer

class App : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                add(DropboxKeyer())
                add(DropboxFetcher.Factory(this@App))
                add(LocalThumbKeyer())
                add(LocalThumbFetcher.Factory(this@App))
            }
            .crossfade(true)
            .build()
}
