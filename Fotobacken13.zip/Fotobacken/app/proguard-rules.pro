# Dropbox-SDK:n och Jackson (JSON) använder reflektion – behåll dem hela.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.dropbox.core.** { *; }
-keep class com.fasterxml.jackson.** { *; }

# Valfria beroenden i Dropbox-SDK:n som inte används på Android.
-dontwarn com.dropbox.core.**
-dontwarn com.fasterxml.jackson.**
-dontwarn com.google.appengine.**
-dontwarn javax.servlet.**
-dontwarn okhttp3.**
-dontwarn com.squareup.okhttp.**
-dontwarn org.joda.time.**
-dontwarn javax.annotation.**
-dontwarn org.slf4j.**
-ignorewarnings
