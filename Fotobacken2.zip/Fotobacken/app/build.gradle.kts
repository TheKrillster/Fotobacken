plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val dropboxKey: String = (System.getenv("DROPBOX_APP_KEY")?.takeIf { it.isNotBlank() }
    ?: (project.findProperty("DROPBOX_APP_KEY") as String?) ?: "").trim()
val hasKeystore = file("fotobacken.keystore").exists()

android {
    namespace = "se.krill.fotobacken"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.krill.fotobacken"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
        manifestPlaceholders["dropboxKey"] = dropboxKey.ifEmpty { "saknas" }
        buildConfigField("String", "DROPBOX_APP_KEY", "\"$dropboxKey\"")
    }

    signingConfigs {
        create("fast") {
            storeFile = file("fotobacken.keystore")
            storePassword = "fotobacken"
            keyAlias = "fotobacken"
            keyPassword = "fotobacken"
        }
    }

    buildTypes {
        debug {
            if (hasKeystore) signingConfig = signingConfigs.getByName("fast")
        }
        release {
            isMinifyEnabled = false
            if (hasKeystore) signingConfig = signingConfigs.getByName("fast")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module"
            )
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okio:okio:3.9.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.dropbox.core:dropbox-core-sdk:5.4.6")
}
