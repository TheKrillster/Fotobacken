@file:OptIn(ExperimentalFoundationApi::class)

package se.krill.fotobacken.ui

import android.app.Activity
import android.os.Build
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Precision
import kotlinx.coroutines.launch
import se.krill.fotobacken.data.Photo
import java.text.SimpleDateFormat
import java.util.Date

@Composable
fun ViewerScreen(vm: GalleryViewModel, screen: Screen.Viewer) {
    val ctx = LocalContext.current
    val hidden by vm.prefs.hiddenPhotos.collectAsStateWithLifecycle()
    val removed by vm.removedKeys.collectAsStateWithLifecycle()
    val favorites by vm.prefs.favorites.collectAsStateWithLifecycle()
    val list = remember(screen, hidden, removed) {
        screen.photos.filter { (it.key in hidden) == screen.hiddenMode && it.key !in removed }
    }

    if (list.isEmpty()) {
        LaunchedEffect(Unit) { vm.pop() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }

    val screenMax = remember {
        val dm = ctx.resources.displayMetrics
        maxOf(dm.widthPixels, dm.heightPixels)
    }
    val startKey = screen.photos.getOrNull(screen.index)?.key
    val pager = rememberPagerState(
        initialPage = list.indexOfFirst { it.key == startKey }.coerceAtLeast(0)
    ) { list.size }
    var chrome by remember { mutableStateOf(true) }
    var info by remember { mutableStateOf<Photo?>(null) }
    var confirmDelete by remember { mutableStateOf<Photo?>(null) }
    val host = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res -> vm.onDeleteResult(res.resultCode == Activity.RESULT_OK) }

    fun startDelete(p: Photo) {
        val sender = vm.requestDelete(ctx, p)
        if (sender != null) deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
    }

    fun onlyOnPhone() {
        Toast.makeText(ctx, "Fungerar bara för bilder på mobilen", Toast.LENGTH_SHORT).show()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pager,
            key = { list[it].key },
            beyondViewportPageCount = 2,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            ZoomableImage(list[page], screenMax, onTap = { chrome = !chrome })
        }

        val current = list[pager.currentPage.coerceIn(0, list.lastIndex)]
        val isFavorite = current.key in favorites

        // Övre raden: tillbaka, namn, info och dölj
        AnimatedVisibility(
            visible = chrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { vm.pop() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Tillbaka", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        current.name,
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${pager.currentPage + 1} av ${list.size}",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                IconButton(onClick = { info = current }) {
                    Icon(Icons.Outlined.Info, contentDescription = "Information", tint = Color.White)
                }
                IconButton(onClick = {
                    val k = listOf(current.key)
                    if (screen.hiddenMode) vm.unhidePhotos(k) else vm.hidePhotos(k)
                    scope.launch {
                        host.currentSnackbarData?.dismiss()
                        val r = host.showSnackbar(
                            if (screen.hiddenMode) "Bilden visas igen" else "Bilden är dold",
                            actionLabel = "Ångra",
                            duration = SnackbarDuration.Short,
                        )
                        if (r == SnackbarResult.ActionPerformed) {
                            if (screen.hiddenMode) vm.hidePhotos(k) else vm.unhidePhotos(k)
                        }
                    }
                }) {
                    Icon(
                        if (screen.hiddenMode) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                        contentDescription = if (screen.hiddenMode) "Visa igen" else "Dölj",
                        tint = Color.White,
                    )
                }
            }
        }

        // Nedre raden: dela, favorit, redigera, ta bort
        AnimatedVisibility(
            visible = chrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
                    .navigationBarsPadding()
                    .padding(top = 18.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                ViewerAction(Icons.Outlined.Share, "Dela") {
                    if (current.isDropbox) vm.shareDropbox(ctx, current) else vm.share(ctx, setOf(current.key))
                }
                ViewerAction(
                    icon = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    label = "Favorit",
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary else Color.White,
                ) { vm.toggleFavorite(current.key) }
                ViewerAction(Icons.Outlined.Edit, "Redigera", enabled = !current.isDropbox) {
                    if (current.isDropbox) onlyOnPhone() else vm.edit(ctx, current)
                }
                ViewerAction(Icons.Outlined.Delete, "Ta bort", enabled = !current.isDropbox) {
                    when {
                        current.isDropbox -> onlyOnPhone()
                        Build.VERSION.SDK_INT >= 30 -> startDelete(current) // Android frågar själv
                        else -> confirmDelete = current
                    }
                }
            }
        }

        SnackbarHost(
            host,
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 80.dp),
        )
    }

    info?.let { p -> InfoDialog(p) { info = null } }
    confirmDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Ta bort bilden?") },
            text = { Text("”${p.name}” raderas från mobilen. Det går inte att ångra.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    startDelete(p)
                }) { Text("Ta bort") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Avbryt") } },
        )
    }
}

@Composable
private fun ViewerAction(
    icon: ImageVector,
    label: String,
    enabled: Boolean = true,
    tint: Color = Color.White,
    onClick: () -> Unit,
) {
    val alpha = if (enabled) 1f else 0.4f
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = tint.copy(alpha = alpha), modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f * alpha), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ZoomableImage(photo: Photo, screenMax: Int, onTap: () -> Unit) {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var detailed by remember { mutableStateOf(false) }

    fun clamp(o: Offset, s: Float): Offset {
        val maxX = size.width * (s - 1f) / 2f
        val maxY = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
    }

    val state = rememberTransformableState { zoom, pan, _ ->
        val ns = (scale * zoom).coerceIn(1f, 5f)
        scale = ns
        if (ns > 1.4f) detailed = true
        offset = if (ns <= 1f) Offset.Zero else clamp(offset + pan, ns)
    }

    // Skärmstorlek räcker när man bläddrar. Miniatyren från rutnätet visas direkt medan bilden laddas.
    val request = remember(photo.key) {
        ImageRequest.Builder(ctx)
            .data(photo.full)
            .size(screenMax)
            .precision(Precision.INEXACT)
            .placeholderMemoryCacheKey(thumbCacheKey(photo))
            .crossfade(false)
            .build()
    }
    // Skarpare version först när man zoomar in.
    val detailRequest = remember(photo.key, detailed) {
        if (!detailed) null
        else ImageRequest.Builder(ctx)
            .data(photo.full)
            .size(screenMax * 2)
            .precision(Precision.INEXACT)
            .crossfade(false)
            .build()
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(photo.key) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.5f
                            detailed = true
                        }
                    },
                )
            }
            .transformable(state = state, canPan = { scale > 1f }),
        contentAlignment = Alignment.Center,
    ) {
        val layer = Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            }
        AsyncImage(model = request, contentDescription = photo.name, contentScale = ContentScale.Fit, modifier = layer)
        if (detailRequest != null) {
            AsyncImage(model = detailRequest, contentDescription = null, contentScale = ContentScale.Fit, modifier = layer)
        }
    }
}

@Composable
private fun InfoDialog(photo: Photo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val date = if (photo.date > 0) SimpleDateFormat("d MMMM yyyy 'kl.' HH:mm", swedish).format(Date(photo.date)) else null
    val place = when {
        photo.isDropbox -> "Dropbox"
        photo.onSdCard -> "Minneskort"
        else -> "Mobilen"
    }
    val rows = buildList {
        add("Namn" to photo.name)
        date?.let { add("Datum" to it) }
        add("Mapp" to (photo.location?.takeIf { it.isNotBlank() } ?: photo.folderName))
        add("Lagring" to place)
        if (photo.width > 0 && photo.height > 0) add("Mått" to "${photo.width} × ${photo.height}")
        if (photo.size > 0) add("Storlek" to Formatter.formatShortFileSize(ctx, photo.size))
        if (photo.isDropbox) add("Sökväg" to photo.key.removePrefix("d:"))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Stäng") } },
        title = { Text("Information") },
        text = {
            Column {
                rows.forEach { (label, value) ->
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(value, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                }
            }
        },
    )
}
