package se.krill.fotobacken.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val scheme = darkColorScheme(
    primary = Color(0xFFE8A33D),
    onPrimary = Color(0xFF241605),
    primaryContainer = Color(0xFF4A3414),
    onPrimaryContainer = Color(0xFFFFDDB0),
    secondary = Color(0xFFC9B08A),
    secondaryContainer = Color(0xFF4A3414),
    onSecondaryContainer = Color(0xFFFFDDB0),
    background = Color(0xFF16130F),
    onBackground = Color(0xFFEDE3D4),
    surface = Color(0xFF16130F),
    onSurface = Color(0xFFEDE3D4),
    surfaceVariant = Color(0xFF2A241D),
    onSurfaceVariant = Color(0xFFBFB2A0),
    surfaceContainer = Color(0xFF201B16),
    surfaceContainerHigh = Color(0xFF2A241D),
    outline = Color(0xFF6E6354),
)

@Composable
fun FotobackenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
