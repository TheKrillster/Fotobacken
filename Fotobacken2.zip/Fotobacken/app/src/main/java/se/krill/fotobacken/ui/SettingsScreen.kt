@file:OptIn(ExperimentalMaterial3Api::class)

package se.krill.fotobacken.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NewReleases
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemColors
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import se.krill.fotobacken.BuildConfig

private val itemColors: ListItemColors
    @Composable get() = ListItemDefaults.colors(containerColor = Color.Transparent)

@Composable
fun SettingsScreen(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    val hiddenList by vm.hiddenPhotoList.collectAsStateWithLifecycle()
    val lock by vm.prefs.lockHidden.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val connected by vm.dropboxConnected.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Inställningar") }, navigationIcon = { BackButton { vm.pop() } })
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            SectionTitle("Galleri")
            ListItem(
                headlineContent = { Text("Mappar som visas") },
                supportingContent = { Text("Välj vilka mappar som syns i galleriet") },
                leadingContent = { Icon(Icons.Outlined.FolderOpen, null) },
                trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) },
                colors = itemColors,
                modifier = Modifier.clickable { vm.push(Screen.FolderSettings) },
            )
            ListItem(
                headlineContent = { Text("Dolda bilder") },
                supportingContent = { Text(bilder(hiddenList.size)) },
                leadingContent = { Icon(Icons.Outlined.VisibilityOff, null) },
                trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null) },
                colors = itemColors,
                modifier = Modifier.clickable {
                    val activity = ctx.findActivity()
                    if (lock && activity != null) unlock(activity) { vm.push(Screen.Hidden) }
                    else vm.push(Screen.Hidden)
                },
            )
            ListItem(
                headlineContent = { Text("Lås dolda bilder") },
                supportingContent = { Text("Kräv fingeravtryck eller PIN för att se dem") },
                leadingContent = { Icon(Icons.Outlined.Fingerprint, null) },
                trailingContent = { Switch(checked = lock, onCheckedChange = { vm.prefs.setLockHidden(it) }) },
                colors = itemColors,
            )
            ListItem(
                headlineContent = { Text("Bilder per rad") },
                leadingContent = { Icon(Icons.Outlined.GridView, null) },
                trailingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(3, 4, 5).forEach { n ->
                            FilterChip(
                                selected = cols == n,
                                onClick = { vm.prefs.setColumns(n) },
                                label = { Text("$n") },
                            )
                        }
                    }
                },
                colors = itemColors,
            )

            SectionTitle("Dropbox")
            when {
                !vm.dropboxConfigured -> ListItem(
                    headlineContent = { Text("Inte inställt") },
                    supportingContent = { Text("Den här versionen är byggd utan Dropbox-nyckel") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null) },
                    colors = itemColors,
                )
                connected -> ListItem(
                    headlineContent = { Text("Ansluten") },
                    supportingContent = { Text("Appen kan läsa dina bilder i Dropbox") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = { TextButton(onClick = { vm.disconnectDropbox() }) { Text("Koppla från") } },
                    colors = itemColors,
                )
                else -> ListItem(
                    headlineContent = { Text("Inte ansluten") },
                    leadingContent = { Icon(Icons.Filled.Cloud, null) },
                    trailingContent = {
                        TextButton(onClick = { vm.startDropboxAuth(ctx.findActivity() ?: ctx) }) { Text("Anslut") }
                    },
                    colors = itemColors,
                )
            }

            SectionTitle("Om")
            ListItem(
                headlineContent = { Text("Fotobacken") },
                supportingContent = { Text("Version ${BuildConfig.VERSION_NAME}") },
                leadingContent = { Icon(Icons.Outlined.Info, null) },
                colors = itemColors,
            )
        }
    }
}

@Composable
fun FolderSettingsScreen(vm: GalleryViewModel) {
    val folders by vm.allFolders.collectAsStateWithLifecycle()
    val hidden by vm.prefs.hiddenFolders.collectAsStateWithLifecycle()
    val auto by vm.prefs.autoShowNew.collectAsStateWithLifecycle()
    val hasPerm by vm.hasPermission.collectAsStateWithLifecycle()
    val dbxHidden = hidden.filter { it.startsWith("df:") }.sorted()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Mappar som visas") }, navigationIcon = { BackButton { vm.pop() } })
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item {
                ListItem(
                    headlineContent = { Text("Visa nya mappar automatiskt") },
                    supportingContent = { Text("Annars är nya mappar dolda tills du slår på dem här") },
                    leadingContent = { Icon(Icons.Outlined.NewReleases, null) },
                    trailingContent = { Switch(checked = auto, onCheckedChange = { vm.prefs.setAutoShowNew(it) }) },
                    colors = itemColors,
                )
            }
            item {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    SectionTitle("På mobilen", Modifier.weight(1f))
                    if (folders.isNotEmpty()) {
                        TextButton(onClick = {
                            vm.prefs.updateHiddenFolders { set -> set.filterNot { it.startsWith("lf:") }.toSet() }
                        }) { Text("Visa alla") }
                        TextButton(onClick = {
                            vm.prefs.updateHiddenFolders { set -> set + folders.map { it.key } }
                        }) { Text("Dölj alla") }
                    }
                }
            }
            if (!hasPerm) {
                item {
                    Text(
                        "Appen har inte tillgång till bilderna på mobilen än.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
            items(folders, key = { it.key }) { f ->
                val visible = f.key !in hidden
                ListItem(
                    headlineContent = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        val parts = buildList {
                            if (f.onSdCard) add("SD-kort")
                            add(bilder(f.count))
                            f.location?.takeIf { it.isNotBlank() }?.let { add(it) }
                        }
                        Text(parts.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    leadingContent = {
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            f.cover?.let {
                                AsyncImage(
                                    model = it.thumb,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    },
                    trailingContent = {
                        Switch(checked = visible, onCheckedChange = { vm.setFolderHidden(f.key, !it) })
                    },
                    colors = itemColors,
                    modifier = Modifier.clickable { vm.setFolderHidden(f.key, visible) },
                )
            }
            item { SectionTitle("Dolda Dropbox-mappar") }
            if (dbxHidden.isEmpty()) {
                item {
                    Text(
                        "Inga. Dölj en Dropbox-mapp genom att hålla in den i Dropbox-fliken.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
            items(dbxHidden, key = { it }) { k ->
                val path = k.removePrefix("df:")
                ListItem(
                    headlineContent = { Text(path.substringAfterLast('/').ifEmpty { "Dropbox" }) },
                    supportingContent = { Text(path, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = { TextButton(onClick = { vm.setFolderHidden(k, false) }) { Text("Visa igen") } },
                    colors = itemColors,
                )
            }
            item { Box(Modifier.padding(bottom = 32.dp)) }
        }
    }
}
