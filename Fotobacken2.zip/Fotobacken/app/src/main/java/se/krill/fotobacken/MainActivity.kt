package se.krill.fotobacken

import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import se.krill.fotobacken.ui.AppRoot
import se.krill.fotobacken.ui.FotobackenTheme
import se.krill.fotobacken.ui.GalleryViewModel

class MainActivity : FragmentActivity() {
    private val vm: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            FotobackenTheme { AppRoot(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshLocal()
        vm.checkDropboxAuthResult()
    }

    override fun onStop() {
        super.onStop()
        vm.closeHiddenScreens()
    }
}
