package se.krill.fotobacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun AppRoot(vm: GalleryViewModel) {
    // Registreras först, så skärmarnas egna bakåt-hanterare går före när de är aktiva.
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.pop() }

    val top = vm.stack.lastOrNull()
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Flikarna ligger kvar under så att scrollpositionen sparas.
        MainTabs(vm, active = top == null)
        if (top != null) {
            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                when (top) {
                    is Screen.Folder -> FolderScreen(vm, top)
                    is Screen.Viewer -> ViewerScreen(vm, top)
                    is Screen.Settings -> SettingsScreen(vm)
                    is Screen.FolderSettings -> FolderSettingsScreen(vm)
                    is Screen.Hidden -> HiddenScreen(vm)
                    is Screen.Favorites -> FavoritesScreen(vm)
                }
            }
        }
    }
}
