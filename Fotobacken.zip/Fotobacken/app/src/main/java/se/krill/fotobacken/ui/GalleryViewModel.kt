package se.krill.fotobacken.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dropbox.core.InvalidAccessTokenException
import com.dropbox.core.android.Auth
import com.dropbox.core.oauth.DbxCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import se.krill.fotobacken.BuildConfig
import se.krill.fotobacken.data.DbxFolderContent
import se.krill.fotobacken.data.DropboxRepo
import se.krill.fotobacken.data.Folder
import se.krill.fotobacken.data.LocalRepo
import se.krill.fotobacken.data.Permissions
import se.krill.fotobacken.data.Photo
import se.krill.fotobacken.data.Prefs

enum class Tab { Photos, Folders, Dropbox }

sealed interface Screen {
    data class Folder(val key: String, val name: String) : Screen
    data class Viewer(val photos: List<Photo>, val index: Int, val hiddenMode: Boolean = false) : Screen
    data object Settings : Screen
    data object FolderSettings : Screen
    data object Hidden : Screen
}

sealed interface DbxListing {
    data object Loading : DbxListing
    data class Ready(val content: DbxFolderContent) : DbxListing
    data class Failed(val message: String) : DbxListing
}

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    // ---------- Bilder på mobilen ----------
    private val local = MutableStateFlow<List<Photo>>(emptyList())
    val localLoaded = MutableStateFlow(false)
    val hasPermission = MutableStateFlow(Permissions.hasAny(app))
    val partialAccess = MutableStateFlow(Permissions.isPartial(app))

    val visiblePhotos: StateFlow<List<Photo>> =
        combine(local, prefs.hiddenPhotos, prefs.hiddenFolders) { all, hp, hf ->
            all.filter { it.key !in hp && it.folderKey !in hf }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val folders: StateFlow<List<Folder>> =
        combine(local, prefs.hiddenPhotos, prefs.hiddenFolders) { all, hp, hf ->
            buildFolders(all.filter { it.key !in hp }).filter { it.key !in hf }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Alla mappar, även dolda – för inställningssidan. */
    val allFolders: StateFlow<List<Folder>> =
        local.map { list -> buildFolders(list).sortedBy { it.name.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val hiddenPhotoList: StateFlow<List<Photo>> =
        combine(local, prefs.hiddenPhotos) { all, hp ->
            val localHidden = all.filter { it.key in hp }
            val dbxHidden = hp.filter { it.startsWith("d:") }.sorted().map { DropboxRepo.photoFromKey(it) }
            localHidden + dbxHidden
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun buildFolders(list: List<Photo>): List<Folder> =
        list.groupBy { it.folderKey }
            .map { (key, ps) ->
                Folder(
                    key = key,
                    name = ps.first().folderName,
                    count = ps.size,
                    cover = ps.first(),
                    onSdCard = ps.any { it.onSdCard },
                    location = ps.first().location,
                )
            }
            .sortedByDescending { it.cover?.date ?: 0L }

    fun refreshLocal() {
        val ctx: Context = getApplication()
        hasPermission.value = Permissions.hasAny(ctx)
        partialAccess.value = Permissions.isPartial(ctx)
        if (!hasPermission.value) {
            local.value = emptyList()
            localLoaded.value = true
            return
        }
        viewModelScope.launch {
            val photos = withContext(Dispatchers.IO) {
                runCatching { LocalRepo.load(ctx) }.getOrDefault(emptyList())
            }
            applyNewFolderRule(photos)
            local.value = photos
            localLoaded.value = true
        }
    }

    private fun applyNewFolderRule(photos: List<Photo>) {
        val keys = photos.map { it.folderKey }.toSet()
        val known = prefs.knownFolders
        val fresh = keys - known
        if (fresh.isEmpty()) return
        if (known.isNotEmpty() && !prefs.autoShowNew.value) {
            prefs.updateHiddenFolders { it + fresh }
        }
        prefs.knownFolders = known + keys
    }

    // ---------- Dölja ----------
    fun hidePhotos(keys: Collection<String>) = prefs.updateHiddenPhotos { it + keys }
    fun unhidePhotos(keys: Collection<String>) = prefs.updateHiddenPhotos { it - keys.toSet() }
    fun setFolderHidden(key: String, hidden: Boolean) =
        prefs.updateHiddenFolders { if (hidden) it + key else it - key }

    fun share(ctx: Context, keys: Set<String>) {
        val uris: List<Uri> = local.value.filter { it.key in keys }.mapNotNull { it.uri }
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(intent, "Dela"))
    }

    // ---------- Navigering ----------
    val stack = mutableStateListOf<Screen>()
    var tab by mutableStateOf(Tab.Photos)

    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    /** Stänger dolda bilder när appen hamnar i bakgrunden. */
    fun closeHiddenScreens() {
        if (!prefs.lockHidden.value) return
        val i = stack.indexOfFirst { it is Screen.Hidden || (it is Screen.Viewer && it.hiddenMode) }
        if (i >= 0) while (stack.size > i) stack.removeAt(stack.lastIndex)
    }

    fun refresh() {
        if (tab == Tab.Dropbox) loadDropbox(dbxPath.last(), force = true) else refreshLocal()
    }

    // ---------- Dropbox ----------
    val dropboxConfigured: Boolean = BuildConfig.DROPBOX_APP_KEY.isNotBlank()
    val dropboxConnected = MutableStateFlow(false)
    val dbxPath = mutableStateListOf("")
    val dbxListings = mutableStateMapOf<String, DbxListing>()
    private var awaitingAuth = false

    init {
        prefs.dropboxCredential?.let { saved ->
            val cred = runCatching { DbxCredential.Reader.readFully(saved) }.getOrNull()
            if (cred != null) {
                DropboxRepo.connect(cred)
                dropboxConnected.value = true
            }
        }
    }

    fun startDropboxAuth(ctx: Context) {
        if (!dropboxConfigured) return
        awaitingAuth = true
        Auth.startOAuth2PKCE(
            ctx,
            BuildConfig.DROPBOX_APP_KEY,
            DropboxRepo.config,
            listOf("account_info.read", "files.metadata.read", "files.content.read"),
        )
    }

    fun checkDropboxAuthResult() {
        if (!awaitingAuth) return
        val cred = Auth.getDbxCredential() ?: return
        awaitingAuth = false
        prefs.dropboxCredential = DbxCredential.Writer.writeToString(cred)
        DropboxRepo.connect(cred)
        dbxListings.clear()
        dbxPath.clear()
        dbxPath.add("")
        dropboxConnected.value = true
        loadDropbox("")
    }

    fun disconnectDropbox() {
        prefs.dropboxCredential = null
        dropboxConnected.value = false
        dbxListings.clear()
        dbxPath.clear()
        dbxPath.add("")
        val ctx: Context = getApplication()
        viewModelScope.launch(Dispatchers.IO) { DropboxRepo.disconnect(ctx) }
    }

    fun openDropboxFolder(path: String) { dbxPath.add(path) }

    fun dropboxUp(): Boolean {
        if (dbxPath.size <= 1) return false
        dbxPath.removeAt(dbxPath.lastIndex)
        return true
    }

    fun loadDropbox(path: String, force: Boolean = false) {
        if (!dropboxConnected.value) return
        val cur = dbxListings[path]
        if (!force && (cur is DbxListing.Ready || cur is DbxListing.Loading)) return
        if (cur !is DbxListing.Ready) dbxListings[path] = DbxListing.Loading
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { DropboxRepo.list(path) } }
            dbxListings[path] = r.fold(
                onSuccess = { DbxListing.Ready(it) },
                onFailure = { e ->
                    DbxListing.Failed(
                        if (e is InvalidAccessTokenException) "Inloggningen har gått ut. Anslut Dropbox igen under Inställningar."
                        else "Kunde inte hämta mappen: ${e.message ?: e.javaClass.simpleName}"
                    )
                },
            )
        }
    }
}
