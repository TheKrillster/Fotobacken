@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package se.krill.fotobacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import se.krill.fotobacken.data.Photo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val swedish: Locale = Locale("sv", "SE")

fun bilder(n: Int): String = if (n == 1) "1 bild" else "$n bilder"

sealed interface GridEntry {
    data class Header(val text: String) : GridEntry
    data class Item(val photo: Photo, val index: Int) : GridEntry
}

fun groupByMonth(photos: List<Photo>): List<GridEntry> {
    val fmt = SimpleDateFormat("LLLL yyyy", swedish)
    val out = ArrayList<GridEntry>(photos.size + 32)
    var last = ""
    photos.forEachIndexed { i, p ->
        val m = if (p.date > 0) fmt.format(Date(p.date)).replaceFirstChar { it.uppercase() } else "Okänt datum"
        if (m != last) {
            out.add(GridEntry.Header(m))
            last = m
        }
        out.add(GridEntry.Item(p, i))
    }
    return out
}

fun flatEntries(photos: List<Photo>): List<GridEntry> = photos.mapIndexed { i, p -> GridEntry.Item(p, i) }

@Composable
fun PhotoTile(
    photo: Photo,
    selected: Boolean,
    selecting: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val pad by animateDpAsState(if (selected) 10.dp else 0.dp, label = "tilePad")
    Box(
        Modifier
            .aspectRatio(1f)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = photo.thumb,
            contentDescription = photo.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .clip(RoundedCornerShape(if (selected) 8.dp else 0.dp)),
        )
        if (selecting) {
            Icon(
                imageVector = if (selected) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else Color.White,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .size(22.dp),
            )
        }
    }
}

@Composable
fun PhotoGrid(
    entries: List<GridEntry>,
    columns: Int,
    selection: Set<String>,
    onOpen: (Int) -> Unit,
    onToggle: (String) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState(),
    topContent: (LazyGridScope.() -> Unit)? = null,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        state = state,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 2.dp, end = 2.dp, top = 2.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        topContent?.invoke(this)
        items(
            items = entries,
            key = { e ->
                when (e) {
                    is GridEntry.Header -> "h:" + e.text
                    is GridEntry.Item -> e.photo.key
                }
            },
            span = { e -> if (e is GridEntry.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1) },
            contentType = { e -> if (e is GridEntry.Header) 0 else 1 },
        ) { e ->
            when (e) {
                is GridEntry.Header -> Text(
                    e.text,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 10.dp, top = 16.dp, bottom = 6.dp),
                )
                is GridEntry.Item -> PhotoTile(
                    photo = e.photo,
                    selected = e.photo.key in selection,
                    selecting = selection.isNotEmpty(),
                    onClick = {
                        if (selection.isNotEmpty()) onToggle(e.photo.key) else onOpen(e.index)
                    },
                    onLongClick = { onToggle(e.photo.key) },
                )
            }
        }
    }
}

@Composable
fun BackButton(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Tillbaka")
    }
}

@Composable
fun SelectionBar(
    count: Int,
    hiddenMode: Boolean,
    onClear: () -> Unit,
    onSelectAll: () -> Unit,
    onShare: (() -> Unit)?,
    onHide: () -> Unit,
) {
    TopAppBar(
        title = { Text("$count valda") },
        navigationIcon = {
            IconButton(onClick = onClear) { Icon(Icons.Filled.Close, contentDescription = "Avbryt") }
        },
        actions = {
            IconButton(onClick = onSelectAll) { Icon(Icons.Filled.SelectAll, contentDescription = "Markera alla") }
            if (onShare != null) {
                IconButton(onClick = onShare) { Icon(Icons.Filled.Share, contentDescription = "Dela") }
            }
            IconButton(onClick = onHide) {
                Icon(
                    if (hiddenMode) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                    contentDescription = if (hiddenMode) "Visa igen" else "Dölj",
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
    )
}

/**
 * Scaffold som byter till markeringsläge när bilder är markerade.
 * Sköter Dölj/Visa igen med Ångra och delning av bilder från mobilen.
 */
@Composable
fun SelectionScaffold(
    vm: GalleryViewModel,
    selection: Set<String>,
    onSelectionChange: (Set<String>) -> Unit,
    allKeys: () -> List<String>,
    topBar: @Composable () -> Unit,
    hiddenMode: Boolean = false,
    active: Boolean = true,
    bottomBar: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    val ctx = LocalContext.current
    val host = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    BackHandler(enabled = active && selection.isNotEmpty()) { onSelectionChange(emptySet()) }

    Scaffold(
        topBar = {
            if (selection.isNotEmpty()) {
                SelectionBar(
                    count = selection.size,
                    hiddenMode = hiddenMode,
                    onClear = { onSelectionChange(emptySet()) },
                    onSelectAll = { onSelectionChange(allKeys().toSet()) },
                    onShare = if (selection.all { it.startsWith("l:") }) {
                        { vm.share(ctx, selection) }
                    } else null,
                    onHide = {
                        val keys = selection
                        onSelectionChange(emptySet())
                        if (hiddenMode) vm.unhidePhotos(keys) else vm.hidePhotos(keys)
                        scope.launch {
                            host.currentSnackbarData?.dismiss()
                            val msg = if (hiddenMode) "${bilder(keys.size)} visas igen"
                            else if (keys.size == 1) "1 bild dold" else "${keys.size} bilder dolda"
                            val r = host.showSnackbar(msg, actionLabel = "Ångra", duration = SnackbarDuration.Short)
                            if (r == SnackbarResult.ActionPerformed) {
                                if (hiddenMode) vm.hidePhotos(keys) else vm.unhidePhotos(keys)
                            }
                        }
                    },
                )
            } else {
                topBar()
            }
        },
        bottomBar = bottomBar,
        snackbarHost = { SnackbarHost(host) },
        containerColor = MaterialTheme.colorScheme.background,
        content = content,
    )
}

@Composable
fun CenterMessage(
    icon: ImageVector,
    title: String,
    text: String,
    modifier: Modifier = Modifier,
    action: Pair<String, () -> Unit>? = null,
    secondary: Pair<String, () -> Unit>? = null,
) {
    Box(modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            if (action != null) {
                Spacer(Modifier.height(20.dp))
                Button(onClick = action.second) { Text(action.first) }
            }
            if (secondary != null) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = secondary.second) { Text(secondary.first) }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp),
    )
}
