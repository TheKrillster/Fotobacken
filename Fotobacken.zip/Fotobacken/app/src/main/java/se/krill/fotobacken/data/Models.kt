package se.krill.fotobacken.data

import android.net.Uri

/** En bild, antingen från mobilen ("l:…") eller från Dropbox ("d:…"). */
data class Photo(
    val key: String,
    val thumb: Any,
    val full: Any,
    val name: String,
    val folderKey: String,
    val folderName: String,
    val date: Long,
    val size: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val uri: Uri? = null,
    val onSdCard: Boolean = false,
    val location: String? = null,
) {
    val isDropbox: Boolean get() = key.startsWith("d:")
}

data class Folder(
    val key: String,
    val name: String,
    val count: Int,
    val cover: Photo?,
    val onSdCard: Boolean,
    val location: String?,
)

/** Modell som Coil laddar via DropboxFetcher. */
data class DropboxImage(val path: String, val large: Boolean)

data class DbxFolder(val name: String, val path: String)

data class DbxFolderContent(val folders: List<DbxFolder>, val photos: List<Photo>)
