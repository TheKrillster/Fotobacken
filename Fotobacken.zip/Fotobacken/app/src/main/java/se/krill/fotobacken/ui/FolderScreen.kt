@file:OptIn(ExperimentalMaterial3Api::class)

package se.krill.fotobacken.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ImageNotSupported
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FolderScreen(vm: GalleryViewModel, screen: Screen.Folder) {
    val all by vm.visiblePhotos.collectAsStateWithLifecycle()
    val cols by vm.prefs.columns.collectAsStateWithLifecycle()
    val photos = remember(all, screen.key) { all.filter { it.folderKey == screen.key } }
    val entries = remember(photos) { groupByMonth(photos) }
    var selection by remember { mutableStateOf(emptySet<String>()) }
    var confirmHide by remember { mutableStateOf(false) }

    SelectionScaffold(
        vm = vm,
        selection = selection,
        onSelectionChange = { selection = it },
        allKeys = { photos.map { it.key } },
        topBar = {
            TopAppBar(
                title = { Text(screen.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { BackButton { vm.pop() } },
                actions = {
                    IconButton(onClick = { confirmHide = true }) {
                        Icon(Icons.Outlined.VisibilityOff, contentDescription = "Dölj mappen")
                    }
                },
            )
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (photos.isEmpty()) {
                CenterMessage(
                    icon = Icons.Outlined.ImageNotSupported,
                    title = "Inga bilder att visa",
                    text = "Mappen är tom, eller så är alla bilder här dolda.",
                )
            } else {
                PhotoGrid(
                    entries = entries,
                    columns = cols,
                    selection = selection,
                    onOpen = { i -> vm.push(Screen.Viewer(photos, i)) },
                    onToggle = { k -> selection = if (k in selection) selection - k else selection + k },
                )
            }
        }
    }

    if (confirmHide) {
        HideFolderDialog(
            name = screen.name,
            onConfirm = {
                confirmHide = false
                vm.setFolderHidden(screen.key, true)
                vm.pop()
            },
            onDismiss = { confirmHide = false },
        )
    }
}
